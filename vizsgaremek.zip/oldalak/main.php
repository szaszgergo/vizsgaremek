<div class="text">
    <h1>Üdvözlünk a FitZone Gymnél!</h1>
    <p>Érje el velünk fitneszcéljait. Csatlakozzon motivált egyének közösségéhez, és alakítsa át testét és elméjét.</p>
    <button onclick='window.top.location.href = "./?o=arak";' class="btn btn-warning">Csatlakozz</button>
    <button class="btn btn-dark">Learn More</button>

</div>